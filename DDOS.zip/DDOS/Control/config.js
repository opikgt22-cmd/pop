///Note : Lu Boleh Jual Script Ini Dengan Harga Murah / Mahal, Namun If You Share Free I Will forgive you
///=> Created Alka & Evil
module.exports = {
  BOT_TOKEN: "YOU_FATHER_TOKEN",
};